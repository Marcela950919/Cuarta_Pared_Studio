## Santiago Andrade Ordo�ez
* **Rol de la industria:** Dise�ador de videojuegos
* **Ubicaci�n:** Santiago de Cali, Colombia
* **Perfil:**. Estudiante de Ingenieria Multimedia orientado al Dise�o y apartado visual.
* **Mi plato favorito:** 
![Plato favorito](plato_favorito.jpg)
* **Mi foto personal:** 
![Foto personal](Santiago_foto_personal.jpg)